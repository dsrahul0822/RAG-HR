from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough, RunnableParallel
from langchain_core.output_parsers import StrOutputParser


def _build_prompt():
    """
    Build the prompt template for the RAG chain
    """
    return ChatPromptTemplate.from_template(
        """
        You are an HR Assistant. Answer the question strictly using the context below. you should only take the context and give exactly what mentioned in there. If any values are coming in from the retriver use those value properly in the response.  If the answer is not present, say "I dont't Know".
        context : {context} 
        question : {question}
        """
    )
# Context is nothing but the retrieved documents from the vector store
# Question is the user query

def _build_llm():
    """
    Build the LLM for the RAG chain
    """
    return ChatOpenAI(model="gpt-3.5-turbo", temperature=0.0)


def build_rag_chain(retriever):
    """
    Build the RAG chain using ChatOpenai and the provided retriever.
    """
    llm = _build_llm()
    prompt = _build_prompt()
    chain = (
        {"context":retriever, 
         "question":RunnablePassthrough()} | prompt | llm | StrOutputParser()
    )
    return chain


def build_rag_chain_with_sources(retriever):
    """
    Build a RAG chain that returns BOTH the answer and the retrieved contexts.
    Used by the RAGAS evaluation pipeline.

    Returns a chain whose .invoke(question) gives:
        {
            "question": <str>,
            "answer":   <str>,
            "contexts": [<str>, <str>, ...]  # raw page_content of retrieved docs
        }
    """
    llm = _build_llm()
    prompt = _build_prompt()

    # First fetch docs once, then run answer generation and pass docs through in parallel
    def _format_docs(docs):
        return "\n\n".join(d.page_content for d in docs)

    def _docs_to_contexts(docs):
        return [d.page_content for d in docs]

    answer_chain = (
        {
            "context": lambda x: _format_docs(x["docs"]),
            "question": lambda x: x["question"],
        }
        | prompt
        | llm
        | StrOutputParser()
    )

    chain = (
        RunnableParallel(
            question=RunnablePassthrough(),
            docs=retriever,
        )
        | RunnableParallel(
            question=lambda x: x["question"],
            contexts=lambda x: _docs_to_contexts(x["docs"]),
            answer=answer_chain,
        )
    )
    return chain