"""
Golden test set for evaluating the Employee Handbook RAG system.

All questions and ground_truth answers below are grounded in the actual
content of data/employee_handbook.pdf. Each entry includes a comment
showing the handbook section it was sourced from.

Structure of each entry:
  - question:     the question to ask the RAG pipeline
  - ground_truth: the reference / expected answer
                  (used by RAGAS for context_recall and answer_correctness)

Notes:
  - Questions are phrased the way a real employee might ask them
    (not just paraphrases of the section headings) to make the test realistic.
  - The last two entries are "negative" / out-of-scope questions whose
    ground_truth is "I don't know" - these test whether the RAG correctly
    abstains instead of hallucinating. The prompt in chains/rag_chain.py
    already instructs the model to say "I don't know" when the answer
    is not in the context.
"""

TEST_SET = [
    # ---- Section 1: Office Timings ----
    {
        "question": "What are the office working hours?",
        "ground_truth": (
            "The office operates from 9:00 AM to 6:00 PM, Monday to Friday. "
            "Employees are expected to be logged in by 9:30 AM. "
            "Lunch break is from 1:00 PM to 2:00 PM."
        ),
    },
    {
        "question": "What happens if I am late to office multiple times in a month?",
        "ground_truth": (
            "Late arrivals beyond three occurrences in a month may require "
            "managerial intervention."
        ),
    },

    # ---- Section 2: Leave Policy ----
    {
        "question": "How many paid leaves am I entitled to in a year?",
        "ground_truth": (
            "Employees are entitled to 18 paid leaves annually, which includes "
            "12 casual/sick leaves and 6 privilege leaves."
        ),
    },
    {
        "question": "Can unused leaves be carried forward to the next year?",
        "ground_truth": (
            "Yes, unused leaves can be carried forward up to a maximum of 30 days."
        ),
    },
    {
        "question": "How and when should I apply for leave?",
        "ground_truth": (
            "All leave applications should be submitted via the HRMS at least "
            "3 days in advance, except in emergencies."
        ),
    },

    # ---- Section 3: Work From Home Policy ----
    {
        "question": "How many work-from-home days are allowed per month?",
        "ground_truth": (
            "Employees can avail up to 5 work-from-home (WFH) days per month, "
            "subject to managerial approval."
        ),
    },
    {
        "question": "What is the process if I need to work from home for more than 3 days continuously?",
        "ground_truth": (
            "Prolonged WFH requests of more than 3 days continuously must be "
            "routed through HR for review. WFH should be requested via email "
            "with a valid reason."
        ),
    },

    # ---- Section 4: Dress Code ----
    {
        "question": "What is the dress code at the office?",
        "ground_truth": (
            "Smart casuals are allowed on all working days. Employees are "
            "expected to dress formally during client visits or online client "
            "calls. Wearing company-branded T-shirts on Fridays is encouraged "
            "as a team-spirit activity."
        ),
    },

    # ---- Section 5: Code of Conduct ----
    {
        "question": "What is the company's policy on workplace harassment and discrimination?",
        "ground_truth": (
            "All employees must maintain a respectful, inclusive, and "
            "collaborative work environment. Any form of discrimination, "
            "harassment, or misconduct will be subject to strict disciplinary "
            "action. Confidential information must not be shared outside the "
            "organization."
        ),
    },

    # ---- Section 6: IT and Security Policy ----
    {
        "question": "Can I use my personal laptop for office work?",
        "ground_truth": (
            "No. All work should be carried out using company-issued devices. "
            "Usage of pirated software or accessing unauthorized websites is "
            "strictly prohibited."
        ),
    },
    {
        "question": "Who should I contact if there is a system malfunction or security threat?",
        "ground_truth": (
            "In case of a system malfunction or security threat, report "
            "immediately to IT support at it@company.com."
        ),
    },

    # ---- Section 7: Probation and Confirmation ----
    {
        "question": "What is the probation period for new employees?",
        "ground_truth": (
            "New employees will undergo a probation period of 6 months. "
            "Performance reviews are conducted during this time, and upon "
            "successful completion, employees receive a confirmation letter "
            "and become eligible for additional benefits."
        ),
    },

    # ---- Section 8: Performance Appraisal ----
    {
        "question": "When are performance appraisals conducted and on what basis?",
        "ground_truth": (
            "Performance reviews are held annually, typically in March. "
            "Appraisal is based on project delivery, teamwork, innovation, "
            "and client feedback. Employees are encouraged to maintain a goal "
            "sheet on the HRMS portal."
        ),
    },

    # ---- Section 9: Learning and Development ----
    {
        "question": "Does the company reimburse certification costs?",
        "ground_truth": (
            "Yes. The organization provides certification reimbursements of "
            "up to INR 15,000 per year. Employees also have access to online "
            "courses and internal workshops. For learning and development, "
            "employees can reach out to training@company.com."
        ),
    },

    # ---- Section 10: Emergency Contacts ----
    {
        "question": "What is the emergency helpline number?",
        "ground_truth": (
            "The emergency helpline number is +91-9876543210. In case of "
            "medical or personal emergencies during office hours, employees "
            "should contact HR immediately."
        ),
    },
    {
        "question": "How often are fire drills conducted?",
        "ground_truth": (
            "Fire drills are conducted quarterly, and all employees are "
            "expected to participate."
        ),
    },

    # ---- Negative / out-of-scope tests (handbook does not cover these) ----
    # These verify the RAG correctly says "I don't know" instead of
    # hallucinating. Faithfulness should still score high on these.
    {
        "question": "What is the maternity leave policy?",
        "ground_truth": "I don't know",
    },
    {
        "question": "What is the notice period for resignation?",
        "ground_truth": "I don't know",
    },
]
