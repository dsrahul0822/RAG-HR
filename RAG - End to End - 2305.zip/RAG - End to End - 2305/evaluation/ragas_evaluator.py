"""
Core RAGAS evaluation logic.

Takes a RAGService instance + a list of test questions, runs each question
through the pipeline, collects (question, answer, contexts, ground_truth)
tuples, and computes RAGAS metrics on them.
"""
"""
Core RAGAS evaluation logic.
"""

from typing import List, Dict
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    context_precision,
    context_recall,
)
from langchain_openai import ChatOpenAI, OpenAIEmbeddings


def collect_predictions(rag_service, test_set: List[Dict]) -> Dict[str, list]:
    questions, answers, contexts, ground_truths = [], [], [], []
    for i, item in enumerate(test_set, start=1):
        q = item["question"]
        gt = item["ground_truth"]
        print(f"  [{i}/{len(test_set)}] {q}")
        result = rag_service.ask_with_contexts(q)
        questions.append(q)
        answers.append(result["answer"])
        contexts.append(result["contexts"])
        ground_truths.append(gt)
    return {
        "question": questions,
        "answer": answers,
        "contexts": contexts,
        "ground_truth": ground_truths,
    }


def run_ragas(predictions: Dict[str, list]):
    """
    Run RAGAS metrics on the collected predictions.
    Explicitly passes the LLM and embeddings model so RAGAS does not
    fall back to a broken default (which causes answer_relevancy to
    fail with 'OpenAIEmbeddings has no attribute embed_query').
    """
    dataset = Dataset.from_dict(predictions)

    # Same models you use in the RAG pipeline — pass them explicitly to RAGAS
    judge_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    judge_embeddings = OpenAIEmbeddings(model="text-embedding-3-large")

    metrics = [
        faithfulness,
        answer_relevancy,
        context_precision,
        context_recall,
    ]

    print("\nRunning RAGAS metrics (this calls the LLM/embeddings as judges)...")
    result = evaluate(
        dataset=dataset,
        metrics=metrics,
        llm=judge_llm,
        embeddings=judge_embeddings,
    )
    return result