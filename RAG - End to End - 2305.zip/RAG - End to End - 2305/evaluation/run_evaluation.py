"""
Run RAGAS evaluation on the Employee Handbook RAG pipeline.

Usage (from project root):
    python -m evaluation.run_evaluation

Outputs:
    evaluation/results/ragas_<timestamp>.csv   (per-question scores)
    evaluation/results/ragas_<timestamp>.json  (summary scores)

Make sure your .env contains OPENAI_API_KEY before running.
"""

import os
import sys
import json
from datetime import datetime
from dotenv import load_dotenv

# Make project root importable when running as `python -m evaluation.run_evaluation`
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

load_dotenv()

from main import RAGService
from evaluation.testset import TEST_SET
from evaluation.ragas_evaluator import collect_predictions, run_ragas


RESULTS_DIR = os.path.join(os.path.dirname(__file__), "results")


def main():
    if not os.environ.get("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY is not set. Add it to .env or export it.")
        sys.exit(1)

    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("=" * 60)
    print("RAGAS Evaluation - Employee Handbook RAG")
    print("=" * 60)
    print(f"Test set size: {len(TEST_SET)} questions\n")

    # 1. Load the RAG pipeline
    print("Step 1: Loading RAG service...")
    rag = RAGService()

    # 2. Run each test question through the pipeline
    print("\nStep 2: Generating answers + collecting contexts...")
    predictions = collect_predictions(rag, TEST_SET)

    # 3. Compute RAGAS metrics
    print("\nStep 3: Computing RAGAS metrics...")
    result = run_ragas(predictions)

    # 4. Print + save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join(RESULTS_DIR, f"ragas_{timestamp}.csv")
    json_path = os.path.join(RESULTS_DIR, f"ragas_{timestamp}.json")

    df = result.to_pandas()
    df.to_csv(csv_path, index=False)

    # Aggregate (mean) score per metric
    summary = {}
    for col in df.columns:
        if col in ("question", "answer", "contexts", "ground_truth"):
            continue
        try:
            summary[col] = float(df[col].mean())
        except Exception:
            pass

    with open(json_path, "w") as f:
        json.dump(
            {
                "timestamp": timestamp,
                "num_questions": len(TEST_SET),
                "summary_scores": summary,
            },
            f,
            indent=2,
        )

    print("\n" + "=" * 60)
    print("RAGAS RESULTS (mean across all questions)")
    print("=" * 60)
    for metric, score in summary.items():
        print(f"  {metric:25s} : {score:.4f}")
    print("=" * 60)
    print(f"\nPer-question scores -> {csv_path}")
    print(f"Summary scores      -> {json_path}")


if __name__ == "__main__":
    main()
