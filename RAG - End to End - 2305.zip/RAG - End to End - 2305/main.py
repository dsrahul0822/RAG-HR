import os 
from dotenv import load_dotenv
from loader.pdf_loader import load_pdf
from splitter.splitter import split_documents
from embedding.openai_embedding import get_embedding
from vectorstore.chroma_store import create_chroma_store, load_chroma_store
from retriever.retriever import get_retriever
from chain.rag_chain import build_rag_chain, build_rag_chain_with_sources

load_dotenv()

PDF_PATH = "data/employee_handbook.pdf"
PERSIST_DIR = "hr_db"

class RAGService:
    def __init__(self):
        embeddings = get_embedding()

        if not os.path.exists(PERSIST_DIR):
            print("Creating new chroma DB...")
            documents = load_pdf(PDF_PATH)
            chunks = split_documents(documents)
            vectordb = create_chroma_store(
                chunks, embeddings, persist_dir=PERSIST_DIR
            )
        else:
            print("Loading existing chroma DB...")
            vectordb = load_chroma_store(
                embeddings, persist_dir=PERSIST_DIR
            )

        self.retriever = get_retriever(vectordb)
        self.rag_chain = build_rag_chain(self.retriever)
        # Built lazily on first evaluation call
        self._rag_chain_with_sources = None

    def ask(self, query: str) -> str:
        """Return only the answer string (used by CLI and Streamlit)."""
        return self.rag_chain.invoke(query)

    def ask_with_contexts(self, query: str) -> dict:
        """
        Return answer AND retrieved contexts.
        Used by the RAGAS evaluation pipeline.
        """
        if self._rag_chain_with_sources is None:
            self._rag_chain_with_sources = build_rag_chain_with_sources(self.retriever)
        return self._rag_chain_with_sources.invoke(query)


def main():
    rag = RAGService()

    print("Employee Handbook RAG Application")
    print("Type 'exit' to quit.")

    while True:
        query = input("\nEnter your question: ")
        if query.lower() == "exit":
            print("Exiting the application. Goodbye!")
            break
        answer = rag.ask(query)
        print(f"Answer: {answer}")

if __name__ == "__main__":
    main()
    








